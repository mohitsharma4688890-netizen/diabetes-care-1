import { sql } from 'drizzle-orm';
import {
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Blood sugar readings for user progress tracking
export const bloodSugarReadings = pgTable("blood_sugar_readings", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: varchar("user_id").notNull().references(() => users.id),
  bloodSugarLevel: real("blood_sugar_level").notNull(),
  readingType: varchar("reading_type", { length: 20 }).notNull(), // 'fasting' or 'random'
  stage: varchar("stage", { length: 20 }).notNull(),
  healthScore: integer("health_score").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type BloodSugarReading = typeof bloodSugarReadings.$inferSelect;
export type InsertBloodSugarReading = typeof bloodSugarReadings.$inferInsert;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bloodSugarReadings: many(bloodSugarReadings),
}));

export const bloodSugarReadingsRelations = relations(bloodSugarReadings, ({ one }) => ({
  user: one(users, {
    fields: [bloodSugarReadings.userId],
    references: [users.id],
  }),
}));

// Diabetes Assessment Input Schema
export const diabetesAssessmentSchema = z.object({
  bloodSugarLevel: z.number().min(50).max(500),
  age: z.number().min(1).max(120),
  fastingOrRandom: z.enum(["fasting", "random"]),
  weight: z.number().optional(),
  height: z.number().optional(),
});

export type DiabetesAssessment = z.infer<typeof diabetesAssessmentSchema>;

// Diabetes Stage Types
export type DiabetesStage = "normal" | "prediabetes" | "type1" | "type2";

// Assessment Result
export interface AssessmentResult {
  stage: DiabetesStage;
  riskLevel: "low" | "moderate" | "high" | "critical";
  healthScore: number;
  bloodSugarStatus: string;
  description: string;
  recommendations: string[];
  nextSteps: string[];
}

// Recommendation Types
export interface Recommendation {
  id: string;
  title: string;
  description: string;
  category: "do" | "dont";
  icon: string;
  priority: number;
}

// Food Item for Dietary Guidelines
export interface FoodItem {
  id: string;
  name: string;
  category: "recommended" | "moderate" | "avoid";
  impact: string;
  description: string;
  imageUrl?: string;
}

// Care Center
export interface CareCenter {
  id: string;
  name: string;
  address: string;
  phone: string;
  rating: number;
  distance: string;
  specialties: string[];
  latitude: number;
  longitude: number;
  imageUrl?: string;
}

// Educational Fact
export interface DiabetesFact {
  id: string;
  title: string;
  content: string;
  category: string;
}

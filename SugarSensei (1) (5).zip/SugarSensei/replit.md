# DiabetesCare - Diabetes Management & Health Assessment Platform

## Overview
DiabetesCare is a comprehensive diabetes management website that helps users assess their diabetes risk level, track their blood sugar readings over time, and provides personalized health recommendations. The platform features stunning animations, interactive assessments, and user authentication via Google login.

## Current State
- **Phase**: MVP Complete
- **Features Implemented**:
  - Health assessment form with blood sugar level slider
  - Diabetes stage classification (Normal, Prediabetes, Type 1, Type 2)
  - User authentication (Google/Replit Auth)
  - Blood sugar reading tracking with progress dashboard
  - Do's and Don'ts recommendations
  - Dietary guidelines with food categorization
  - Care centers directory
  - Educational carousel about diabetes
  - Dark/Light theme toggle
  - Particle background animations
  - Typing animations
  - Framer Motion animations throughout

## Project Structure
```
├── client/src/
│   ├── components/
│   │   ├── AnimatedCounter.tsx    # Animated number counter
│   │   ├── AssessmentForm.tsx     # Multi-step health assessment
│   │   ├── CareCenters.tsx        # Care centers directory
│   │   ├── CircularProgress.tsx   # Animated progress ring
│   │   ├── DietaryGuidelines.tsx  # Food recommendations
│   │   ├── EducationalCarousel.tsx# Diabetes facts carousel
│   │   ├── Footer.tsx             # Site footer
│   │   ├── HeroSection.tsx        # Landing hero with particles
│   │   ├── Navbar.tsx             # Navigation bar
│   │   ├── ParticleBackground.tsx # tsParticles background
│   │   ├── ProgressTracker.tsx    # User progress dashboard
│   │   ├── RecommendationsSection.tsx # Do's & Don'ts
│   │   ├── ResultsDashboard.tsx   # Assessment results display
│   │   └── ThemeToggle.tsx        # Dark/Light mode toggle
│   ├── hooks/
│   │   └── useAuth.ts             # Authentication hook
│   ├── lib/
│   │   ├── authUtils.ts           # Auth helper functions
│   │   └── queryClient.ts         # TanStack Query setup
│   ├── pages/
│   │   ├── Home.tsx               # Logged-in user dashboard
│   │   ├── Landing.tsx            # Public landing page
│   │   └── not-found.tsx          # 404 page
│   └── App.tsx                    # Main app router
├── server/
│   ├── db.ts                      # Database connection
│   ├── replitAuth.ts              # Authentication setup
│   ├── routes.ts                  # API endpoints
│   └── storage.ts                 # Database operations
└── shared/
    └── schema.ts                  # Database schema & types
```

## Database Schema
- **users**: User accounts (Replit Auth)
- **sessions**: Session management
- **blood_sugar_readings**: User blood sugar tracking

## API Endpoints
- `GET /api/auth/user` - Get current user
- `GET /api/readings` - Get user's blood sugar readings
- `POST /api/readings` - Save new blood sugar reading
- `GET /api/readings/latest` - Get latest reading
- `POST /api/assess` - Process health assessment

## Tech Stack
- **Frontend**: React, Tailwind CSS, Framer Motion, tsParticles
- **Backend**: Express.js, PostgreSQL, Drizzle ORM
- **Auth**: Replit Auth (OpenID Connect)
- **Animations**: Framer Motion, React Type Animation

## Running the Project
```bash
npm run dev  # Starts both frontend and backend
```

## User Preferences
- Medical/health-themed color scheme (teal/cyan primary)
- Extensive animations throughout
- Dark mode support
- Smooth transitions and micro-interactions

import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { diabetesAssessmentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(server: Server, app: Express): Promise<void> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes - NOT protected so clients can check auth status
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      if (!req.isAuthenticated() || !req.user?.claims?.sub) {
        return res.json(null);
      }
      
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.json(null);
    }
  });

  // Blood sugar readings endpoints
  app.get("/api/readings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const readings = await storage.getReadingsByUser(userId);
      res.json(readings);
    } catch (error) {
      console.error("Error fetching readings:", error);
      res.status(500).json({ message: "Failed to fetch readings" });
    }
  });

  const createReadingSchema = z.object({
    bloodSugarLevel: z.number().min(50).max(500),
    readingType: z.enum(["fasting", "random"]),
    stage: z.string(),
    healthScore: z.number().min(0).max(100),
    notes: z.string().optional(),
  });

  app.post("/api/readings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = createReadingSchema.parse(req.body);
      
      const reading = await storage.createReading({
        userId,
        bloodSugarLevel: validatedData.bloodSugarLevel,
        readingType: validatedData.readingType,
        stage: validatedData.stage,
        healthScore: validatedData.healthScore,
        notes: validatedData.notes,
      });
      
      res.status(201).json(reading);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
        return;
      }
      console.error("Error creating reading:", error);
      res.status(500).json({ message: "Failed to save reading" });
    }
  });

  app.get("/api/readings/latest", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reading = await storage.getLatestReading(userId);
      if (!reading) {
        res.status(404).json({ message: "No readings found" });
        return;
      }
      res.json(reading);
    } catch (error) {
      console.error("Error fetching latest reading:", error);
      res.status(500).json({ message: "Failed to fetch reading" });
    }
  });

  // Health assessment endpoint (for non-logged in users)
  app.post("/api/assess", async (req, res) => {
    try {
      const validatedData = diabetesAssessmentSchema.parse(req.body);
      
      const { bloodSugarLevel, age, fastingOrRandom } = validatedData;
      
      let stage: string;
      let riskLevel: string;
      let healthScore: number;
      let bloodSugarStatus: string;
      let description: string;

      if (fastingOrRandom === "fasting") {
        if (bloodSugarLevel < 100) {
          stage = "normal";
          riskLevel = "low";
          healthScore = 90 - Math.floor(age / 10);
          bloodSugarStatus = "Normal Range";
          description = "Your fasting blood sugar level is within the normal range.";
        } else if (bloodSugarLevel < 126) {
          stage = "prediabetes";
          riskLevel = "moderate";
          healthScore = 70 - Math.floor(age / 10);
          bloodSugarStatus = "Prediabetes Range";
          description = "Your blood sugar indicates prediabetes.";
        } else {
          stage = "type2";
          riskLevel = bloodSugarLevel >= 200 ? "critical" : "high";
          healthScore = Math.max(30, 50 - Math.floor((bloodSugarLevel - 126) / 5) - Math.floor(age / 10));
          bloodSugarStatus = "Diabetes Range";
          description = "Your blood sugar level indicates diabetes.";
        }
      } else {
        if (bloodSugarLevel < 140) {
          stage = "normal";
          riskLevel = "low";
          healthScore = 85 - Math.floor(age / 10);
          bloodSugarStatus = "Normal Range";
          description = "Your random blood sugar level is within the normal range.";
        } else if (bloodSugarLevel < 200) {
          stage = "prediabetes";
          riskLevel = "moderate";
          healthScore = 65 - Math.floor(age / 10);
          bloodSugarStatus = "Elevated Range";
          description = "Your blood sugar is elevated.";
        } else {
          stage = "type2";
          riskLevel = bloodSugarLevel >= 300 ? "critical" : "high";
          healthScore = Math.max(25, 45 - Math.floor((bloodSugarLevel - 200) / 10) - Math.floor(age / 10));
          bloodSugarStatus = "High Range";
          description = "Your random blood sugar is significantly elevated.";
        }
      }

      healthScore = Math.max(10, Math.min(100, healthScore));

      res.json({
        stage,
        riskLevel,
        healthScore,
        bloodSugarStatus,
        description,
        recommendations: [],
        nextSteps: [],
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
        return;
      }
      console.error("Error processing assessment:", error);
      res.status(500).json({ message: "Failed to process assessment" });
    }
  });
}

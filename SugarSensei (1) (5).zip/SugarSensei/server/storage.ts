import {
  users,
  bloodSugarReadings,
  type User,
  type UpsertUser,
  type BloodSugarReading,
  type InsertBloodSugarReading,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Blood sugar readings operations
  createReading(reading: InsertBloodSugarReading): Promise<BloodSugarReading>;
  getReadingsByUser(userId: string): Promise<BloodSugarReading[]>;
  getLatestReading(userId: string): Promise<BloodSugarReading | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Blood sugar readings operations
  async createReading(reading: InsertBloodSugarReading): Promise<BloodSugarReading> {
    const [newReading] = await db
      .insert(bloodSugarReadings)
      .values(reading)
      .returning();
    return newReading;
  }

  async getReadingsByUser(userId: string): Promise<BloodSugarReading[]> {
    return await db
      .select()
      .from(bloodSugarReadings)
      .where(eq(bloodSugarReadings.userId, userId))
      .orderBy(desc(bloodSugarReadings.createdAt));
  }

  async getLatestReading(userId: string): Promise<BloodSugarReading | undefined> {
    const [reading] = await db
      .select()
      .from(bloodSugarReadings)
      .where(eq(bloodSugarReadings.userId, userId))
      .orderBy(desc(bloodSugarReadings.createdAt))
      .limit(1);
    return reading;
  }
}

export const storage = new DatabaseStorage();

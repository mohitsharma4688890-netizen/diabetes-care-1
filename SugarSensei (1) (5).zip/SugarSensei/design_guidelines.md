# Diabetes Management Website - Design Guidelines

## Design Approach
**Reference-Based + Enhanced Animation Strategy**: Drawing inspiration from modern health tech platforms like Calm, Headspace, and Apple Health, combined with extensive motion design for an engaging, supportive health experience.

## Typography System
- **Primary Font**: Inter or DM Sans (Google Fonts) - clean medical professionalism
- **Display Font**: Outfit or Space Grotesk - for hero headlines and section titles
- **Hierarchy**: 
  - Hero headlines: 3xl to 6xl, bold weight
  - Section titles: 2xl to 4xl, semibold
  - Body text: base to lg, regular weight
  - Medical data/stats: xl to 3xl, bold (numeric emphasis)
  - Labels/captions: sm to base, medium weight

## Spacing & Layout System
**Tailwind Units**: Primary spacing using 4, 8, 12, 16, 20, 24 units (p-4, m-8, gap-12, etc.)
- Section padding: py-16 to py-24 on desktop, py-12 on mobile
- Component spacing: gap-8 for cards, gap-4 within components
- Container: max-w-7xl for full sections, max-w-4xl for forms

## Core Layout Structure

### Hero Section (Full viewport - 90vh)
- Animated gradient background with floating particle effects
- Large hero image showing supportive healthcare imagery (doctor consulting patient, or calming wellness scene)
- Centered headline with typing animation effect revealing text character-by-character
- Subheadline with fade-in delay
- Primary CTA button with pulse animation and blurred glass-morphism background
- Floating health stat cards with number count-up animations

### Assessment Form Section
- Two-column layout on desktop (form left, illustration/info right)
- Single column on mobile
- Input fields with floating labels and smooth focus animations
- Range slider for blood sugar level with real-time value display and color-coded markers
- Age input with number stepper
- Progress indicator showing completion percentage
- Submit button with loading spinner and success state animation

### Results Dashboard (Reveals after form submission)
- Full-width section with animated reveal (slide-up + fade-in)
- Large diabetes stage indicator card with icon animation and typing text description
- Health score circular progress bar with animated fill
- Grid of 4-6 metric cards showing: Blood Sugar Status, Risk Level, Recommended Tests, Next Steps
- Each card animates in sequentially with stagger effect

### Recommendations Section (Do's & Don'ts)
- Split-screen layout: Green zone (Do's) and Red zone (Don'ts)
- Icon-based list items that slide in from sides
- Expandable accordion cards for detailed information with smooth height transitions
- Animated checkmarks and X marks for visual reinforcement

### Dietary Guidelines
- Masonry grid of food cards (2-3 columns)
- Each card has image, food name, and impact indicator
- Hover animations with scale and shadow effects
- Color-coded borders (green/yellow/red) with glow effects

### Care Centers Directory
- Interactive map embed (Google Maps or similar) with animated markers
- Side panel with scrollable list of centers
- Each center card includes: name, distance, rating stars (animated fill), contact button
- Filter options with smooth transition animations

### Educational Content Section
- Carousel of diabetes facts with auto-rotate and manual navigation
- Each slide has typing animation for text reveal
- Background images with parallax scroll effect

### Footer
- Multi-column layout: Quick Links, Resources, Emergency Contacts, Newsletter signup
- Social media icons with hover bounce animations
- Disclaimer text with fade-in on scroll

## Animation Specifications

**Page Load Sequence**:
1. Hero background particles fade in (0.5s)
2. Hero headline types out (1.5s)
3. Subheadline fades in (0.3s delay)
4. CTA button slides up (0.5s delay)
5. Floating cards stagger in (0.2s intervals)

**Scroll-Triggered Animations**:
- Sections fade and slide up as they enter viewport
- Number counters animate when visible
- Progress bars fill on scroll
- Cards stagger-animate in grids (0.1s delays between items)

**Interactive Animations**:
- Form inputs: Label floats up on focus, input border glow
- Buttons: Scale on hover, loading spinner on click
- Cards: Subtle lift on hover (translateY + shadow)
- Typing effects: Character-by-character reveal at 50ms intervals
- Accordion expand/collapse with smooth height transitions

**Background Effects**:
- Gradient animation shifting hues slowly (10s loop)
- Floating geometric shapes or health-related icons (pulse, heartbeat)
- Parallax scrolling on hero and section backgrounds

## Component Library

**Cards**: Rounded corners (rounded-xl), subtle shadows (shadow-lg), glass-morphism effect where applicable
**Buttons**: Primary (large, bold), Secondary (outlined), Glass-morphism CTAs on hero
**Input Fields**: Outlined style, floating labels, validation states with icons
**Badges**: Pill-shaped status indicators for diabetes stages
**Progress Indicators**: Circular and linear with animated fills
**Icons**: Heroicons for UI elements, custom health icons for medical content
**Modals**: Centered overlays with backdrop blur for care center details

## Images Strategy

**Required Images**:
1. **Hero Image**: Large (1920x1080) - Supportive healthcare professional with patient or person checking blood sugar with modern device - positioned as background with overlay
2. **Assessment Illustration**: Medical consultation or health monitoring visualization (right side of form)
3. **Food Category Images**: High-quality photos for dietary recommendations (vegetables, proteins, grains)
4. **Care Center Photos**: Facility exterior/interior shots for directory listings
5. **Educational Graphics**: Infographic-style diabetes management visuals
6. **Icon Set**: Medical/health themed icons throughout

**Image Treatment**: Subtle overlays, rounded corners, soft shadows, some with blur/frost glass effects for modern aesthetic

## Accessibility Notes
- Maintain WCAG AA contrast ratios despite animations
- Provide reduced motion preferences respect
- Screen reader-friendly form labels and ARIA attributes
- Keyboard navigation support for all interactive elements

This design creates a supportive, engaging health platform that balances medical professionalism with modern, animated user experience to make diabetes management feel approachable and empowering.
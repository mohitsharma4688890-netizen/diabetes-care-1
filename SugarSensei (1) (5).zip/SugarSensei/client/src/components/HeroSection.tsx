import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ParticleBackground } from "./ParticleBackground";
import { AnimatedCounter } from "./AnimatedCounter";
import { Heart, Activity, Users, Shield, ArrowDown, LogIn } from "lucide-react";
import heroImage from "@assets/stock_images/healthcare_professio_9ac2ef41.jpg";

interface HeroSectionProps {
  isAuthenticated: boolean;
  onGetStarted: () => void;
}

export function HeroSection({ isAuthenticated, onGetStarted }: HeroSectionProps) {
  const stats = [
    { icon: Users, value: 500, suffix: "M+", label: "People Affected" },
    { icon: Heart, value: 95, suffix: "%", label: "Prevention Rate" },
    { icon: Activity, value: 24, suffix: "/7", label: "Support Available" },
    { icon: Shield, value: 100, suffix: "%", label: "Secure & Private" },
  ];

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <ParticleBackground />
      
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/80 to-background dark:from-background/98 dark:via-background/90 dark:to-background" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            >
              <Heart className="w-4 h-4 text-primary heartbeat" />
              <span className="text-sm font-medium text-primary">Your Health, Our Priority</span>
            </motion.div>
          </motion.div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold mb-6 leading-tight">
            <TypeAnimation
              sequence={[
                "Take Control of Your",
                1000,
              ]}
              speed={50}
              cursor={false}
              className="text-foreground"
            />
            <br />
            <span className="gradient-text">
              <TypeAnimation
                sequence={[
                  500,
                  "Diabetes Journey",
                  1000,
                  "Health Today",
                  1000,
                  "Wellness Path",
                  1000,
                  "Diabetes Journey",
                ]}
                speed={50}
                repeat={Infinity}
              />
            </span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
          >
            Discover your diabetes risk level, get personalized recommendations, 
            and connect with care centers near you. Your journey to better health starts here.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button
              size="lg"
              onClick={onGetStarted}
              data-testid="button-get-started"
              className="glow-pulse text-lg px-8 py-6"
            >
              {isAuthenticated ? "Check Your Health" : "Get Started Free"}
              <ArrowDown className="ml-2 w-5 h-5" />
            </Button>
            
            {!isAuthenticated && (
              <Button
                variant="outline"
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-login-hero"
                className="text-lg px-8 py-6"
              >
                <LogIn className="mr-2 w-5 h-5" />
                Sign In
              </Button>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 + index * 0.1, duration: 0.5 }}
              >
                <Card className="p-4 md:p-6 backdrop-blur-sm bg-card/80 border-card-border hover-elevate">
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl md:text-3xl font-bold text-foreground">
                    <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                  </div>
                  <p className="text-xs md:text-sm text-muted-foreground">{stat.label}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <ArrowDown className="w-6 h-6 text-muted-foreground" />
        </motion.div>
      </motion.div>
    </section>
  );
}

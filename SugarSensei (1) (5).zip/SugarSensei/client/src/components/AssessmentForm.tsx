import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Activity, Droplet, Calendar, Weight, Ruler, Loader2 } from "lucide-react";
import glucoseMeterImage from "@assets/stock_images/blood_sugar_glucose__212d93b9.jpg";

const formSchema = z.object({
  bloodSugarLevel: z.number().min(50, "Blood sugar must be at least 50 mg/dL").max(500, "Blood sugar must be below 500 mg/dL"),
  age: z.number().min(1, "Age is required").max(120, "Please enter a valid age"),
  fastingOrRandom: z.enum(["fasting", "random"]),
  weight: z.number().optional(),
  height: z.number().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface AssessmentFormProps {
  onSubmit: (data: FormData) => void;
  isSubmitting: boolean;
}

export function AssessmentForm({ onSubmit, isSubmitting }: AssessmentFormProps) {
  const [bloodSugar, setBloodSugar] = useState(100);
  const [step, setStep] = useState(1);
  const totalSteps = 3;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      bloodSugarLevel: 100,
      age: 30,
      fastingOrRandom: "fasting",
      weight: undefined,
      height: undefined,
    },
  });

  const getBloodSugarColor = (value: number) => {
    if (value < 100) return "text-green-500";
    if (value < 126) return "text-yellow-500";
    if (value < 200) return "text-orange-500";
    return "text-red-500";
  };

  const getBloodSugarLabel = (value: number) => {
    if (value < 100) return "Normal";
    if (value < 126) return "Prediabetes Range";
    if (value < 200) return "Elevated";
    return "High";
  };

  const progress = (step / totalSteps) * 100;

  const handleSubmit = form.handleSubmit((data) => {
    onSubmit({ ...data, bloodSugarLevel: bloodSugar });
  });

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <section id="assessment" className="py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Check Your <span className="gradient-text">Diabetes Risk</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Enter your health details below to get a personalized assessment of your diabetes risk level
            and receive tailored recommendations.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="overflow-hidden">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <CardTitle>Health Assessment</CardTitle>
                    <CardDescription>Step {step} of {totalSteps}</CardDescription>
                  </div>
                  <Activity className="w-6 h-6 text-primary" />
                </div>
                <Progress value={progress} className="mt-4" />
              </CardHeader>

              <CardContent>
                <Form {...form}>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <AnimatePresence mode="wait">
                      {step === 1 && (
                        <motion.div
                          key="step1"
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ duration: 0.3 }}
                          className="space-y-6"
                        >
                          <div className="space-y-4">
                            <div className="flex items-center gap-2">
                              <Droplet className="w-5 h-5 text-primary" />
                              <FormLabel className="text-base">Blood Sugar Level</FormLabel>
                            </div>
                            
                            <div className="text-center mb-4">
                              <motion.span
                                key={bloodSugar}
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                className={`text-5xl font-bold ${getBloodSugarColor(bloodSugar)}`}
                              >
                                {bloodSugar}
                              </motion.span>
                              <span className="text-lg text-muted-foreground ml-2">mg/dL</span>
                              <p className={`text-sm mt-1 ${getBloodSugarColor(bloodSugar)}`}>
                                {getBloodSugarLabel(bloodSugar)}
                              </p>
                            </div>

                            <Slider
                              value={[bloodSugar]}
                              onValueChange={([value]) => setBloodSugar(value)}
                              min={50}
                              max={400}
                              step={1}
                              className="w-full"
                              data-testid="slider-blood-sugar"
                            />
                            
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>50 mg/dL</span>
                              <span>400 mg/dL</span>
                            </div>
                          </div>

                          <FormField
                            control={form.control}
                            name="fastingOrRandom"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Reading Type</FormLabel>
                                <FormControl>
                                  <RadioGroup
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                    className="flex gap-4"
                                  >
                                    <div className="flex items-center space-x-2">
                                      <RadioGroupItem value="fasting" id="fasting" data-testid="radio-fasting" />
                                      <label htmlFor="fasting" className="text-sm cursor-pointer">
                                        Fasting (8+ hours)
                                      </label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <RadioGroupItem value="random" id="random" data-testid="radio-random" />
                                      <label htmlFor="random" className="text-sm cursor-pointer">
                                        Random
                                      </label>
                                    </div>
                                  </RadioGroup>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </motion.div>
                      )}

                      {step === 2 && (
                        <motion.div
                          key="step2"
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ duration: 0.3 }}
                          className="space-y-6"
                        >
                          <FormField
                            control={form.control}
                            name="age"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="flex items-center gap-2">
                                  <Calendar className="w-4 h-4 text-primary" />
                                  Age
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    placeholder="Enter your age"
                                    data-testid="input-age"
                                    {...field}
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="flex items-center gap-2">
                                  <Weight className="w-4 h-4 text-primary" />
                                  Weight (kg) - Optional
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    placeholder="Enter your weight"
                                    data-testid="input-weight"
                                    {...field}
                                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="height"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="flex items-center gap-2">
                                  <Ruler className="w-4 h-4 text-primary" />
                                  Height (cm) - Optional
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    placeholder="Enter your height"
                                    data-testid="input-height"
                                    {...field}
                                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </motion.div>
                      )}

                      {step === 3 && (
                        <motion.div
                          key="step3"
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ duration: 0.3 }}
                          className="space-y-6"
                        >
                          <div className="bg-muted/50 rounded-lg p-6 space-y-4">
                            <h3 className="font-semibold text-lg">Review Your Information</h3>
                            
                            <div className="grid gap-3">
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Blood Sugar</span>
                                <span className={`font-medium ${getBloodSugarColor(bloodSugar)}`}>
                                  {bloodSugar} mg/dL ({getBloodSugarLabel(bloodSugar)})
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Reading Type</span>
                                <span className="font-medium capitalize">{form.watch("fastingOrRandom")}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Age</span>
                                <span className="font-medium">{form.watch("age")} years</span>
                              </div>
                              {form.watch("weight") && (
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Weight</span>
                                  <span className="font-medium">{form.watch("weight")} kg</span>
                                </div>
                              )}
                              {form.watch("height") && (
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Height</span>
                                  <span className="font-medium">{form.watch("height")} cm</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <div className="flex gap-4 pt-4">
                      {step > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={prevStep}
                          className="flex-1"
                          data-testid="button-prev-step"
                        >
                          Previous
                        </Button>
                      )}
                      
                      {step < totalSteps ? (
                        <Button
                          type="button"
                          onClick={nextStep}
                          className="flex-1"
                          data-testid="button-next-step"
                        >
                          Next Step
                        </Button>
                      ) : (
                        <Button
                          type="submit"
                          className="flex-1"
                          disabled={isSubmitting}
                          data-testid="button-submit-assessment"
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Analyzing...
                            </>
                          ) : (
                            "Get My Results"
                          )}
                        </Button>
                      )}
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hidden md:block"
          >
            <div className="relative">
              <img
                src={glucoseMeterImage}
                alt="Blood glucose monitoring"
                className="rounded-xl shadow-2xl object-cover w-full h-[500px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent rounded-xl" />
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
                className="absolute bottom-6 left-6 right-6"
              >
                <Card className="backdrop-blur-sm bg-card/90">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Activity className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">Quick & Accurate</h4>
                        <p className="text-sm text-muted-foreground">
                          Get your diabetes risk assessment in under 2 minutes with personalized recommendations.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

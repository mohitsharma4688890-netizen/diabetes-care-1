import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TypeAnimation } from "react-type-animation";
import { ChevronLeft, ChevronRight, Lightbulb, Info, AlertCircle, Heart } from "lucide-react";

const diabetesFacts = [
  {
    id: "1",
    icon: Info,
    title: "What is Diabetes?",
    content: "Diabetes is a chronic condition where the body cannot properly process blood glucose (sugar). There are three main types: Type 1, Type 2, and Gestational diabetes.",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  {
    id: "2",
    icon: AlertCircle,
    title: "Warning Signs",
    content: "Common symptoms include increased thirst, frequent urination, extreme hunger, unexplained weight loss, fatigue, blurred vision, and slow-healing sores.",
    color: "from-orange-500/20 to-yellow-500/20",
  },
  {
    id: "3",
    icon: Lightbulb,
    title: "Prevention Tips",
    content: "You can prevent or delay Type 2 diabetes by maintaining a healthy weight, staying physically active, eating a balanced diet, and avoiding tobacco use.",
    color: "from-green-500/20 to-emerald-500/20",
  },
  {
    id: "4",
    icon: Heart,
    title: "Living Well with Diabetes",
    content: "Many people with diabetes live healthy, active lives. Regular monitoring, medication adherence, healthy eating, and exercise are key to managing the condition.",
    color: "from-pink-500/20 to-rose-500/20",
  },
  {
    id: "5",
    icon: Info,
    title: "Blood Sugar Levels",
    content: "Normal fasting blood sugar is less than 100 mg/dL. Prediabetes ranges from 100-125 mg/dL. A reading of 126 mg/dL or higher indicates diabetes.",
    color: "from-purple-500/20 to-indigo-500/20",
  },
];

export function EducationalCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % diabetesFacts.length);
    }, 8000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToPrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + diabetesFacts.length) % diabetesFacts.length);
  };

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % diabetesFacts.length);
  };

  const currentFact = diabetesFacts[currentIndex];
  const Icon = currentFact.icon;

  return (
    <section id="education" className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Learn About <span className="gradient-text">Diabetes</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Understanding diabetes is the first step to managing it effectively.
          </p>
        </motion.div>

        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentFact.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
            >
              <Card className={`overflow-hidden bg-gradient-to-br ${currentFact.color}`}>
                <CardContent className="p-8 md:p-12">
                  <div className="flex flex-col items-center text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                      className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6"
                    >
                      <Icon className="w-8 h-8 text-primary" />
                    </motion.div>
                    
                    <h3 className="text-2xl md:text-3xl font-bold mb-4">{currentFact.title}</h3>
                    
                    <div className="text-lg text-muted-foreground max-w-2xl min-h-[80px]">
                      <TypeAnimation
                        key={currentFact.id}
                        sequence={[currentFact.content]}
                        speed={80}
                        cursor={false}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-center gap-4 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={goToPrevious}
              data-testid="button-carousel-prev"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>

            <div className="flex gap-2">
              {diabetesFacts.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setIsAutoPlaying(false);
                    setCurrentIndex(index);
                  }}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentIndex
                      ? "bg-primary w-8"
                      : "bg-muted hover:bg-muted-foreground/50"
                  }`}
                  data-testid={`button-carousel-dot-${index}`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={goToNext}
              data-testid="button-carousel-next"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

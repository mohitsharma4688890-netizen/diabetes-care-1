import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CircularProgress } from "./CircularProgress";
import { AnimatedCounter } from "./AnimatedCounter";
import { 
  Heart, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Activity,
  Stethoscope,
  ClipboardList,
  ArrowRight
} from "lucide-react";
import type { AssessmentResult, DiabetesStage } from "@shared/schema";

interface ResultsDashboardProps {
  result: AssessmentResult;
  bloodSugarLevel: number;
}

const stageConfig: Record<DiabetesStage, { color: string; icon: typeof Heart; bgColor: string }> = {
  normal: { color: "text-green-500", icon: CheckCircle2, bgColor: "bg-green-500/10" },
  prediabetes: { color: "text-yellow-500", icon: AlertTriangle, bgColor: "bg-yellow-500/10" },
  type1: { color: "text-orange-500", icon: AlertTriangle, bgColor: "bg-orange-500/10" },
  type2: { color: "text-red-500", icon: XCircle, bgColor: "bg-red-500/10" },
};

const riskColors = {
  low: "bg-green-500",
  moderate: "bg-yellow-500",
  high: "bg-orange-500",
  critical: "bg-red-500",
};

export function ResultsDashboard({ result, bloodSugarLevel }: ResultsDashboardProps) {
  const config = stageConfig[result.stage];
  const Icon = config.icon;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const stageLabels: Record<DiabetesStage, string> = {
    normal: "Normal",
    prediabetes: "Prediabetes",
    type1: "Type 1 Diabetes Indicators",
    type2: "Type 2 Diabetes Range",
  };

  return (
    <section id="results" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={containerVariants}
          className="space-y-8"
        >
          <motion.div variants={itemVariants} className="text-center">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Your <span className="gradient-text">Health Assessment</span> Results
            </h2>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className={`overflow-hidden border-2 ${config.color.replace("text-", "border-")}`}>
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row items-center gap-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200, delay: 0.3 }}
                    className={`w-32 h-32 rounded-full ${config.bgColor} flex items-center justify-center`}
                  >
                    <Icon className={`w-16 h-16 ${config.color}`} />
                  </motion.div>

                  <div className="flex-1 text-center md:text-left">
                    <Badge variant="secondary" className="mb-4">
                      {result.riskLevel.toUpperCase()} RISK
                    </Badge>
                    <h3 className={`text-3xl font-bold mb-2 ${config.color}`}>
                      {stageLabels[result.stage]}
                    </h3>
                    <div className="text-muted-foreground">
                      <TypeAnimation
                        sequence={[result.description]}
                        speed={70}
                        cursor={false}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col items-center">
                    <CircularProgress
                      value={result.healthScore}
                      max={100}
                      size={140}
                      strokeWidth={10}
                      color={`hsl(var(--${result.healthScore >= 70 ? "chart-3" : result.healthScore >= 40 ? "warning" : "destructive"}))`}
                      label="Health Score"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div variants={itemVariants}>
              <Card className="h-full hover-elevate">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Activity className="w-5 h-5 text-primary" />
                    Blood Sugar Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">
                    <AnimatedCounter value={bloodSugarLevel} suffix=" mg/dL" />
                  </div>
                  <p className="text-sm text-muted-foreground">{result.bloodSugarStatus}</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="h-full hover-elevate">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <AlertTriangle className="w-5 h-5 text-primary" />
                    Risk Level
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${riskColors[result.riskLevel]}`} />
                    <span className="text-2xl font-bold capitalize">{result.riskLevel}</span>
                  </div>
                  <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ 
                        width: result.riskLevel === "low" ? "25%" : 
                               result.riskLevel === "moderate" ? "50%" : 
                               result.riskLevel === "high" ? "75%" : "100%" 
                      }}
                      transition={{ duration: 1, delay: 0.5 }}
                      className={`h-full ${riskColors[result.riskLevel]}`}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="h-full hover-elevate">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Stethoscope className="w-5 h-5 text-primary" />
                    Recommended Tests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    <li className="text-sm flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                      HbA1c Test
                    </li>
                    <li className="text-sm flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                      Oral Glucose Test
                    </li>
                    <li className="text-sm flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                      Lipid Panel
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="h-full hover-elevate">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <ClipboardList className="w-5 h-5 text-primary" />
                    Next Steps
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    {result.nextSteps.slice(0, 3).map((step, index) => (
                      <li key={index} className="text-sm flex items-start gap-2">
                        <ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

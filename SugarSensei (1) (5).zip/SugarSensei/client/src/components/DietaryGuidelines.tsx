import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, AlertTriangle, X } from "lucide-react";
import healthyFoodImage from "@assets/stock_images/healthy_food_vegetab_f1218e58.jpg";

interface FoodItem {
  name: string;
  impact: string;
  icon: string;
}

const recommendedFoods: FoodItem[] = [
  { name: "Leafy Greens", impact: "Very low glycemic index", icon: "🥬" },
  { name: "Berries", impact: "Rich in antioxidants", icon: "🫐" },
  { name: "Whole Grains", impact: "Slow-release energy", icon: "🌾" },
  { name: "Nuts & Seeds", impact: "Healthy fats & protein", icon: "🥜" },
  { name: "Lean Fish", impact: "Omega-3 fatty acids", icon: "🐟" },
  { name: "Legumes", impact: "High fiber content", icon: "🫘" },
  { name: "Eggs", impact: "Complete protein source", icon: "🥚" },
  { name: "Avocado", impact: "Healthy monounsaturated fats", icon: "🥑" },
];

const moderateFoods: FoodItem[] = [
  { name: "Brown Rice", impact: "Moderate glycemic index", icon: "🍚" },
  { name: "Sweet Potatoes", impact: "Better than white potatoes", icon: "🍠" },
  { name: "Whole Wheat Bread", impact: "Watch portions", icon: "🍞" },
  { name: "Bananas", impact: "High in natural sugars", icon: "🍌" },
  { name: "Low-fat Dairy", impact: "Contains natural sugars", icon: "🥛" },
  { name: "Honey", impact: "Use sparingly", icon: "🍯" },
];

const avoidFoods: FoodItem[] = [
  { name: "Sugary Drinks", impact: "Rapid blood sugar spike", icon: "🥤" },
  { name: "White Bread", impact: "High glycemic index", icon: "🥖" },
  { name: "Candy & Sweets", impact: "Pure sugar content", icon: "🍬" },
  { name: "Fried Foods", impact: "Trans fats & carbs", icon: "🍟" },
  { name: "Processed Snacks", impact: "Hidden sugars", icon: "🍿" },
  { name: "Fruit Juices", impact: "Concentrated sugars", icon: "🧃" },
];

export function DietaryGuidelines() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1 },
  };

  const FoodGrid = ({ foods, category }: { foods: FoodItem[]; category: "recommended" | "moderate" | "avoid" }) => {
    const categoryConfig = {
      recommended: { color: "border-green-500/20", bg: "bg-green-500/5", badge: "bg-green-500" },
      moderate: { color: "border-yellow-500/20", bg: "bg-yellow-500/5", badge: "bg-yellow-500" },
      avoid: { color: "border-red-500/20", bg: "bg-red-500/5", badge: "bg-red-500" },
    };

    const config = categoryConfig[category];

    return (
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={containerVariants}
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
      >
        {foods.map((food) => (
          <motion.div key={food.name} variants={itemVariants}>
            <Card className={`h-full hover-elevate transition-all duration-300 ${config.color} ${config.bg}`}>
              <CardContent className="p-4 text-center">
                <div className="text-4xl mb-2">{food.icon}</div>
                <h4 className="font-medium mb-1">{food.name}</h4>
                <p className="text-xs text-muted-foreground">{food.impact}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    );
  };

  return (
    <section id="dietary" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            <span className="gradient-text">Dietary</span> Guidelines
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Make informed food choices to help manage your blood sugar levels effectively.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <Tabs defaultValue="recommended" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="recommended" className="flex items-center gap-2" data-testid="tab-recommended">
                  <Check className="w-4 h-4" />
                  Recommended
                </TabsTrigger>
                <TabsTrigger value="moderate" className="flex items-center gap-2" data-testid="tab-moderate">
                  <AlertTriangle className="w-4 h-4" />
                  Moderate
                </TabsTrigger>
                <TabsTrigger value="avoid" className="flex items-center gap-2" data-testid="tab-avoid">
                  <X className="w-4 h-4" />
                  Avoid
                </TabsTrigger>
              </TabsList>

              <TabsContent value="recommended">
                <div className="mb-4">
                  <Badge className="bg-green-500">Best Choices</Badge>
                  <p className="text-sm text-muted-foreground mt-2">
                    These foods have minimal impact on blood sugar and provide essential nutrients.
                  </p>
                </div>
                <FoodGrid foods={recommendedFoods} category="recommended" />
              </TabsContent>

              <TabsContent value="moderate">
                <div className="mb-4">
                  <Badge className="bg-yellow-500 text-black">Consume in Moderation</Badge>
                  <p className="text-sm text-muted-foreground mt-2">
                    These foods can be part of your diet but should be consumed in controlled portions.
                  </p>
                </div>
                <FoodGrid foods={moderateFoods} category="moderate" />
              </TabsContent>

              <TabsContent value="avoid">
                <div className="mb-4">
                  <Badge className="bg-red-500">Limit or Avoid</Badge>
                  <p className="text-sm text-muted-foreground mt-2">
                    These foods can cause rapid blood sugar spikes and should be minimized or avoided.
                  </p>
                </div>
                <FoodGrid foods={avoidFoods} category="avoid" />
              </TabsContent>
            </Tabs>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="sticky top-24">
              <img
                src={healthyFoodImage}
                alt="Healthy food for diabetes"
                className="rounded-xl shadow-xl object-cover w-full h-[400px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent rounded-xl" />
              
              <Card className="absolute bottom-4 left-4 right-4 backdrop-blur-sm bg-card/90">
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-2">Quick Tip</h4>
                  <p className="text-sm text-muted-foreground">
                    Fill half your plate with non-starchy vegetables, a quarter with lean protein, 
                    and a quarter with whole grains for balanced blood sugar control.
                  </p>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

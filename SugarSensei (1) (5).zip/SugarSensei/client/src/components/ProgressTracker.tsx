import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CircularProgress } from "./CircularProgress";
import { AnimatedCounter } from "./AnimatedCounter";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Calendar,
  Activity,
  Target,
  Award,
  Flame
} from "lucide-react";
import type { BloodSugarReading } from "@shared/schema";

interface ProgressTrackerProps {
  readings: BloodSugarReading[];
}

export function ProgressTracker({ readings }: ProgressTrackerProps) {
  const sortedReadings = [...readings].sort(
    (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
  );

  const latestReading = sortedReadings[0];
  const previousReading = sortedReadings[1];

  const trend = latestReading && previousReading
    ? latestReading.bloodSugarLevel < previousReading.bloodSugarLevel
      ? "down"
      : latestReading.bloodSugarLevel > previousReading.bloodSugarLevel
      ? "up"
      : "stable"
    : "stable";

  const averageBloodSugar = readings.length > 0
    ? Math.round(readings.reduce((acc, r) => acc + r.bloodSugarLevel, 0) / readings.length)
    : 0;

  const normalReadings = readings.filter(r => r.bloodSugarLevel < 100).length;
  const complianceRate = readings.length > 0 
    ? Math.round((normalReadings / readings.length) * 100) 
    : 0;

  const currentStreak = (() => {
    let streak = 0;
    for (const reading of sortedReadings) {
      if (reading.bloodSugarLevel < 140) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  })();

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "normal": return "bg-green-500";
      case "prediabetes": return "bg-yellow-500";
      case "type1": return "bg-orange-500";
      case "type2": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  if (readings.length === 0) {
    return (
      <Card className="p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
          <Activity className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="font-semibold mb-2">No Readings Yet</h3>
        <p className="text-muted-foreground text-sm">
          Complete a health assessment to start tracking your progress!
        </p>
      </Card>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="space-y-6"
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div variants={itemVariants}>
          <Card className="hover-elevate">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Activity className="w-5 h-5 text-primary" />
                {trend === "down" && <TrendingDown className="w-5 h-5 text-green-500" />}
                {trend === "up" && <TrendingUp className="w-5 h-5 text-red-500" />}
                {trend === "stable" && <Minus className="w-5 h-5 text-yellow-500" />}
              </div>
              <p className="text-2xl font-bold">
                <AnimatedCounter value={latestReading?.bloodSugarLevel || 0} suffix=" mg/dL" />
              </p>
              <p className="text-xs text-muted-foreground">Latest Reading</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="hover-elevate">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <p className="text-2xl font-bold">
                <AnimatedCounter value={averageBloodSugar} suffix=" mg/dL" />
              </p>
              <p className="text-xs text-muted-foreground">Average Level</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="hover-elevate">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Award className="w-5 h-5 text-primary" />
              </div>
              <p className="text-2xl font-bold">
                <AnimatedCounter value={complianceRate} suffix="%" />
              </p>
              <p className="text-xs text-muted-foreground">Normal Range</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="hover-elevate">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Flame className="w-5 h-5 text-orange-500" />
              </div>
              <p className="text-2xl font-bold">
                <AnimatedCounter value={currentStreak} suffix=" days" />
              </p>
              <p className="text-xs text-muted-foreground">Healthy Streak</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calendar className="w-5 h-5 text-primary" />
              Recent Readings
            </CardTitle>
            <CardDescription>Your last {Math.min(readings.length, 7)} blood sugar measurements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedReadings.slice(0, 7).map((reading, index) => (
                <motion.div
                  key={reading.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center gap-4"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Badge className={getStageColor(reading.stage)} variant="secondary">
                          {reading.stage}
                        </Badge>
                        <span className="text-sm font-medium">{reading.bloodSugarLevel} mg/dL</span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(reading.createdAt!).toLocaleDateString()}
                      </span>
                    </div>
                    <Progress 
                      value={Math.min((reading.bloodSugarLevel / 200) * 100, 100)} 
                      className="h-2"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6">
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Health Score Trend</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <CircularProgress
                value={latestReading?.healthScore || 0}
                max={100}
                size={160}
                strokeWidth={12}
                color={`hsl(var(--${(latestReading?.healthScore || 0) >= 70 ? "chart-3" : (latestReading?.healthScore || 0) >= 40 ? "warning" : "destructive"}))`}
                label="Score"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Weekly Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Total Readings</span>
                  <span className="font-medium">{readings.length}</span>
                </div>
                <Progress value={(readings.length / 7) * 100} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>In Normal Range</span>
                  <span className="font-medium">{normalReadings} of {readings.length}</span>
                </div>
                <Progress value={complianceRate} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span>Average Health Score</span>
                  <span className="font-medium">
                    {readings.length > 0 
                      ? Math.round(readings.reduce((acc, r) => acc + r.healthScore, 0) / readings.length)
                      : 0}/100
                  </span>
                </div>
                <Progress 
                  value={readings.length > 0 
                    ? Math.round(readings.reduce((acc, r) => acc + r.healthScore, 0) / readings.length)
                    : 0} 
                  className="h-2" 
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}

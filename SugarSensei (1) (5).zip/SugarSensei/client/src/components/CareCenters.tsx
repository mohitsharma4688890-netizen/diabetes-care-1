import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  MapPin, 
  Phone, 
  Star, 
  Navigation,
  Search,
  Building2,
  Clock,
  ChevronRight
} from "lucide-react";
import { useState } from "react";
import hospitalImage from "@assets/stock_images/modern_hospital_medi_de650885.jpg";
import type { CareCenter } from "@shared/schema";

const careCenters: CareCenter[] = [
  {
    id: "1",
    name: "City Diabetes & Endocrine Center",
    address: "123 Medical Plaza, Suite 400",
    phone: "(555) 123-4567",
    rating: 4.8,
    distance: "0.5 miles",
    specialties: ["Endocrinology", "Diabetes Care", "Nutrition"],
    latitude: 40.7128,
    longitude: -74.006,
  },
  {
    id: "2",
    name: "Advanced Metabolic Health Clinic",
    address: "456 Health Center Drive",
    phone: "(555) 234-5678",
    rating: 4.6,
    distance: "1.2 miles",
    specialties: ["Type 1 Diabetes", "Insulin Pump Therapy"],
    latitude: 40.7148,
    longitude: -74.008,
  },
  {
    id: "3",
    name: "Community Wellness Center",
    address: "789 Wellness Boulevard",
    phone: "(555) 345-6789",
    rating: 4.7,
    distance: "2.0 miles",
    specialties: ["Preventive Care", "Nutrition Counseling"],
    latitude: 40.7168,
    longitude: -74.01,
  },
  {
    id: "4",
    name: "University Medical Diabetes Institute",
    address: "1000 University Ave",
    phone: "(555) 456-7890",
    rating: 4.9,
    distance: "3.5 miles",
    specialties: ["Research", "Clinical Trials", "Advanced Treatment"],
    latitude: 40.7188,
    longitude: -74.012,
  },
  {
    id: "5",
    name: "Family Diabetes Care Center",
    address: "555 Family Health Road",
    phone: "(555) 567-8901",
    rating: 4.5,
    distance: "4.0 miles",
    specialties: ["Pediatric Diabetes", "Family Care"],
    latitude: 40.7208,
    longitude: -74.014,
  },
];

export function CareCenters() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCenter, setSelectedCenter] = useState<CareCenter | null>(null);

  const filteredCenters = careCenters.filter(
    (center) =>
      center.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      center.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 },
  };

  return (
    <section id="care-centers" className="py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Find <span className="gradient-text">Diabetes Care Centers</span> Near You
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Connect with specialized diabetes care centers and healthcare professionals in your area.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search by name or specialty..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-centers"
              />
            </div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={containerVariants}
              className="space-y-3 max-h-[500px] overflow-y-auto pr-2"
            >
              {filteredCenters.map((center) => (
                <motion.div key={center.id} variants={itemVariants}>
                  <Card
                    className={`cursor-pointer transition-all hover-elevate ${
                      selectedCenter?.id === center.id ? "ring-2 ring-primary" : ""
                    }`}
                    onClick={() => setSelectedCenter(center)}
                    data-testid={`card-center-${center.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Building2 className="w-4 h-4 text-primary" />
                            <h4 className="font-semibold">{center.name}</h4>
                          </div>
                          
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                            <MapPin className="w-4 h-4" />
                            <span>{center.address}</span>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                              <span className="font-medium">{center.rating}</span>
                            </div>
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Navigation className="w-4 h-4" />
                              <span>{center.distance}</span>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-1 mt-2">
                            {center.specialties.slice(0, 2).map((specialty) => (
                              <Badge key={specialty} variant="secondary" className="text-xs">
                                {specialty}
                              </Badge>
                            ))}
                            {center.specialties.length > 2 && (
                              <Badge variant="secondary" className="text-xs">
                                +{center.specialties.length - 2}
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="overflow-hidden h-full">
              {selectedCenter ? (
                <>
                  <div className="relative h-48">
                    <img
                      src={hospitalImage}
                      alt={selectedCenter.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                  </div>
                  
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-primary" />
                      {selectedCenter.name}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3 text-sm">
                      <MapPin className="w-5 h-5 text-primary" />
                      <span>{selectedCenter.address}</span>
                    </div>
                    
                    <div className="flex items-center gap-3 text-sm">
                      <Phone className="w-5 h-5 text-primary" />
                      <span>{selectedCenter.phone}</span>
                    </div>
                    
                    <div className="flex items-center gap-3 text-sm">
                      <Clock className="w-5 h-5 text-primary" />
                      <span>Open 24/7 for emergencies</span>
                    </div>
                    
                    <div className="flex items-center gap-3 text-sm">
                      <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                      <span>{selectedCenter.rating} out of 5 stars</span>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Specialties:</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedCenter.specialties.map((specialty) => (
                          <Badge key={specialty} variant="secondary">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex gap-4 pt-4">
                      <Button className="flex-1" data-testid="button-call-center">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Now
                      </Button>
                      <Button variant="outline" className="flex-1" data-testid="button-directions">
                        <Navigation className="w-4 h-4 mr-2" />
                        Get Directions
                      </Button>
                    </div>
                  </CardContent>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                  <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
                    <Building2 className="w-10 h-10 text-muted-foreground" />
                  </div>
                  <h4 className="font-semibold mb-2">Select a Care Center</h4>
                  <p className="text-sm text-muted-foreground">
                    Click on a care center from the list to view more details
                  </p>
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

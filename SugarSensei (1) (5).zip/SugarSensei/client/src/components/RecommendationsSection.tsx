import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  Check, 
  X, 
  Dumbbell, 
  Apple, 
  Moon, 
  Droplets,
  Cigarette,
  Wine,
  Cookie,
  Sofa,
  AlertCircle,
  Timer
} from "lucide-react";

const dosRecommendations = [
  {
    id: "exercise",
    icon: Dumbbell,
    title: "Exercise Regularly",
    description: "Aim for 150 minutes of moderate activity per week",
    details: "Regular physical activity helps your body use insulin more efficiently, lowers blood sugar levels, and reduces the risk of heart disease. Try walking, swimming, cycling, or any activity you enjoy.",
  },
  {
    id: "diet",
    icon: Apple,
    title: "Eat a Balanced Diet",
    description: "Focus on vegetables, whole grains, and lean proteins",
    details: "Choose foods that are low in added sugars and refined carbohydrates. Include plenty of fiber-rich vegetables, whole grains, lean proteins, and healthy fats in your meals.",
  },
  {
    id: "sleep",
    icon: Moon,
    title: "Get Quality Sleep",
    description: "Aim for 7-9 hours of sleep each night",
    details: "Poor sleep can affect blood sugar levels and insulin sensitivity. Establish a regular sleep schedule and create a restful environment for better diabetes management.",
  },
  {
    id: "hydration",
    icon: Droplets,
    title: "Stay Hydrated",
    description: "Drink plenty of water throughout the day",
    details: "Water helps your kidneys flush out excess blood sugar through urine. Aim for at least 8 glasses of water daily, and avoid sugary drinks.",
  },
  {
    id: "monitoring",
    icon: Timer,
    title: "Monitor Regularly",
    description: "Track your blood sugar levels consistently",
    details: "Regular monitoring helps you understand how food, activity, and medications affect your blood sugar. Keep a log to share with your healthcare provider.",
  },
];

const dontsRecommendations = [
  {
    id: "smoking",
    icon: Cigarette,
    title: "Avoid Smoking",
    description: "Smoking increases diabetes complications significantly",
    details: "Smoking damages blood vessels and can worsen diabetes complications like heart disease, kidney disease, and nerve damage. Seek help to quit if needed.",
  },
  {
    id: "alcohol",
    icon: Wine,
    title: "Limit Alcohol",
    description: "Excessive alcohol can affect blood sugar control",
    details: "Alcohol can cause blood sugar to drop too low or rise too high. If you drink, do so in moderation and always with food.",
  },
  {
    id: "sugar",
    icon: Cookie,
    title: "Reduce Sugar Intake",
    description: "Minimize sugary foods and beverages",
    details: "Sugary foods cause rapid spikes in blood sugar. Read labels carefully and be aware of hidden sugars in processed foods, sauces, and condiments.",
  },
  {
    id: "sedentary",
    icon: Sofa,
    title: "Avoid Sedentary Lifestyle",
    description: "Reduce prolonged sitting and inactivity",
    details: "Sitting for long periods negatively affects blood sugar and insulin sensitivity. Take breaks to stand, stretch, or walk every 30-60 minutes.",
  },
  {
    id: "skip-meals",
    icon: AlertCircle,
    title: "Don't Skip Meals",
    description: "Maintain regular eating patterns",
    details: "Skipping meals can lead to blood sugar fluctuations and overeating later. Plan regular, balanced meals and healthy snacks to maintain stable blood sugar.",
  },
];

export function RecommendationsSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="recommendations" className="py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            <span className="gradient-text">Do's & Don'ts</span> for Diabetes Care
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Follow these essential guidelines to manage your blood sugar levels effectively 
            and maintain a healthy lifestyle.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <Card className="h-full border-2 border-green-500/20 bg-green-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-600 dark:text-green-400">
                  <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                    <Check className="w-5 h-5" />
                  </div>
                  What To Do
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="space-y-2">
                  {dosRecommendations.map((item, index) => (
                    <motion.div key={item.id} variants={itemVariants}>
                      <AccordionItem value={item.id} className="border-green-500/10">
                        <AccordionTrigger className="hover:no-underline py-3" data-testid={`accordion-do-${item.id}`}>
                          <div className="flex items-center gap-3 text-left">
                            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                              <item.icon className="w-5 h-5 text-green-600 dark:text-green-400" />
                            </div>
                            <div>
                              <p className="font-medium">{item.title}</p>
                              <p className="text-sm text-muted-foreground">{item.description}</p>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pl-14 text-muted-foreground">
                          {item.details}
                        </AccordionContent>
                      </AccordionItem>
                    </motion.div>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <Card className="h-full border-2 border-red-500/20 bg-red-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
                  <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center">
                    <X className="w-5 h-5" />
                  </div>
                  What To Avoid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="space-y-2">
                  {dontsRecommendations.map((item, index) => (
                    <motion.div key={item.id} variants={itemVariants}>
                      <AccordionItem value={item.id} className="border-red-500/10">
                        <AccordionTrigger className="hover:no-underline py-3" data-testid={`accordion-dont-${item.id}`}>
                          <div className="flex items-center gap-3 text-left">
                            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                              <item.icon className="w-5 h-5 text-red-600 dark:text-red-400" />
                            </div>
                            <div>
                              <p className="font-medium">{item.title}</p>
                              <p className="text-sm text-muted-foreground">{item.description}</p>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pl-14 text-muted-foreground">
                          {item.details}
                        </AccordionContent>
                      </AccordionItem>
                    </motion.div>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { AssessmentForm } from "@/components/AssessmentForm";
import { ResultsDashboard } from "@/components/ResultsDashboard";
import { ProgressTracker } from "@/components/ProgressTracker";
import { RecommendationsSection } from "@/components/RecommendationsSection";
import { DietaryGuidelines } from "@/components/DietaryGuidelines";
import { CareCenters } from "@/components/CareCenters";
import { EducationalCarousel } from "@/components/EducationalCarousel";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Activity, BarChart3, Settings, User, Heart } from "lucide-react";
import type { AssessmentResult, DiabetesStage, BloodSugarReading } from "@shared/schema";

function calculateAssessment(
  bloodSugarLevel: number,
  age: number,
  fastingOrRandom: "fasting" | "random"
): AssessmentResult {
  let stage: DiabetesStage;
  let riskLevel: "low" | "moderate" | "high" | "critical";
  let healthScore: number;
  let bloodSugarStatus: string;
  let description: string;

  if (fastingOrRandom === "fasting") {
    if (bloodSugarLevel < 100) {
      stage = "normal";
      riskLevel = "low";
      healthScore = 90 - Math.floor(age / 10);
      bloodSugarStatus = "Normal Range";
      description = "Your fasting blood sugar level is within the normal range. Keep maintaining your healthy lifestyle to stay on track!";
    } else if (bloodSugarLevel < 126) {
      stage = "prediabetes";
      riskLevel = "moderate";
      healthScore = 70 - Math.floor(age / 10);
      bloodSugarStatus = "Prediabetes Range";
      description = "Your blood sugar indicates prediabetes. This is a warning sign, but with lifestyle changes, you can prevent progression to diabetes.";
    } else {
      stage = "type2";
      riskLevel = bloodSugarLevel >= 200 ? "critical" : "high";
      healthScore = Math.max(30, 50 - Math.floor((bloodSugarLevel - 126) / 5) - Math.floor(age / 10));
      bloodSugarStatus = "Diabetes Range";
      description = "Your blood sugar level indicates diabetes. Please consult with a healthcare professional for proper diagnosis and treatment plan.";
    }
  } else {
    if (bloodSugarLevel < 140) {
      stage = "normal";
      riskLevel = "low";
      healthScore = 85 - Math.floor(age / 10);
      bloodSugarStatus = "Normal Range";
      description = "Your random blood sugar level is within the normal range. Continue with your healthy habits!";
    } else if (bloodSugarLevel < 200) {
      stage = "prediabetes";
      riskLevel = "moderate";
      healthScore = 65 - Math.floor(age / 10);
      bloodSugarStatus = "Elevated Range";
      description = "Your blood sugar is elevated. Consider getting a fasting blood sugar test for a more accurate assessment.";
    } else {
      stage = "type2";
      riskLevel = bloodSugarLevel >= 300 ? "critical" : "high";
      healthScore = Math.max(25, 45 - Math.floor((bloodSugarLevel - 200) / 10) - Math.floor(age / 10));
      bloodSugarStatus = "High Range";
      description = "Your random blood sugar is significantly elevated. It's important to see a healthcare provider as soon as possible.";
    }
  }

  healthScore = Math.max(10, Math.min(100, healthScore));

  const recommendations = stage === "normal" 
    ? [
        "Continue regular exercise routine",
        "Maintain balanced diet with whole grains",
        "Schedule annual health checkups",
        "Stay hydrated throughout the day",
      ]
    : stage === "prediabetes"
    ? [
        "Increase physical activity to 150 min/week",
        "Reduce refined carbohydrate intake",
        "Consider meeting with a nutritionist",
        "Monitor blood sugar regularly",
        "Achieve and maintain healthy weight",
      ]
    : [
        "Consult an endocrinologist immediately",
        "Start blood sugar monitoring routine",
        "Follow prescribed medication regimen",
        "Make immediate dietary changes",
        "Consider diabetes education program",
      ];

  const nextSteps = stage === "normal"
    ? ["Annual HbA1c test", "Maintain healthy lifestyle", "Regular exercise"]
    : stage === "prediabetes"
    ? ["Get HbA1c test", "Schedule nutrition consultation", "Start exercise program"]
    : ["Urgent medical consultation", "Complete diabetes panel", "Start treatment plan"];

  return {
    stage,
    riskLevel,
    healthScore,
    bloodSugarStatus,
    description,
    recommendations,
    nextSteps,
  };
}

export default function Home() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null);
  const [currentBloodSugar, setCurrentBloodSugar] = useState(0);
  const [activeTab, setActiveTab] = useState("dashboard");
  const assessmentRef = useRef<HTMLDivElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const { data: readings = [], isLoading: readingsLoading } = useQuery<BloodSugarReading[]>({
    queryKey: ["/api/readings"],
  });

  const saveReadingMutation = useMutation({
    mutationFn: async (data: {
      bloodSugarLevel: number;
      readingType: string;
      stage: string;
      healthScore: number;
    }) => {
      return await apiRequest("POST", "/api/readings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/readings"] });
      toast({
        title: "Reading Saved",
        description: "Your blood sugar reading has been saved to your progress tracker.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save reading. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGetStarted = () => {
    if (activeTab !== "assessment") {
      setActiveTab("assessment");
    }
    setTimeout(() => {
      assessmentRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleNavigate = (section: string) => {
    if (section === "progress") {
      setActiveTab("dashboard");
      return;
    }
    if (section === "profile") {
      setActiveTab("profile");
      return;
    }
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleAssessmentSubmit = async (data: {
    bloodSugarLevel: number;
    age: number;
    fastingOrRandom: "fasting" | "random";
    weight?: number;
    height?: number;
  }) => {
    const result = calculateAssessment(
      data.bloodSugarLevel,
      data.age,
      data.fastingOrRandom
    );
    
    setAssessmentResult(result);
    setCurrentBloodSugar(data.bloodSugarLevel);

    await saveReadingMutation.mutateAsync({
      bloodSugarLevel: data.bloodSugarLevel,
      readingType: data.fastingOrRandom,
      stage: result.stage,
      healthScore: result.healthScore,
    });
    
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        user={user} 
        isLoading={isLoading} 
        onNavigate={handleNavigate}
      />
      
      <main className="pt-20 pb-8">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="flex items-center gap-4 mb-2">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Heart className="w-6 h-6 text-primary heartbeat" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-display font-bold">
                  Welcome back, {user?.firstName || "there"}!
                </h1>
                <p className="text-muted-foreground">
                  Track your health journey and take control of your diabetes management.
                </p>
              </div>
            </div>
          </motion.div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full max-w-lg grid-cols-4">
              <TabsTrigger value="dashboard" className="flex items-center gap-2" data-testid="tab-dashboard">
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger value="assessment" className="flex items-center gap-2" data-testid="tab-assessment">
                <Activity className="w-4 h-4" />
                <span className="hidden sm:inline">Check</span>
              </TabsTrigger>
              <TabsTrigger value="learn" className="flex items-center gap-2" data-testid="tab-learn">
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">Learn</span>
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex items-center gap-2" data-testid="tab-profile">
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Profile</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-2">Your Progress</h2>
                  <p className="text-muted-foreground text-sm">
                    View your blood sugar readings and health trends over time.
                  </p>
                </div>
                
                {readingsLoading ? (
                  <Card className="p-8">
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
                    </div>
                  </Card>
                ) : (
                  <ProgressTracker readings={readings} />
                )}

                <div className="mt-8 text-center">
                  <Button onClick={handleGetStarted} size="lg" data-testid="button-new-reading">
                    <Activity className="mr-2 w-5 h-5" />
                    Record New Reading
                  </Button>
                </div>
              </motion.div>
            </TabsContent>

            <TabsContent value="assessment">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <div ref={assessmentRef}>
                  <AssessmentForm 
                    onSubmit={handleAssessmentSubmit}
                    isSubmitting={saveReadingMutation.isPending}
                  />
                </div>

                {assessmentResult && (
                  <motion.div
                    ref={resultsRef}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                  >
                    <ResultsDashboard 
                      result={assessmentResult}
                      bloodSugarLevel={currentBloodSugar}
                    />
                  </motion.div>
                )}

                <RecommendationsSection />
              </motion.div>
            </TabsContent>

            <TabsContent value="learn">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <DietaryGuidelines />
                <CareCenters />
                <EducationalCarousel />
              </motion.div>
            </TabsContent>

            <TabsContent value="profile">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5 text-primary" />
                      Your Profile
                    </CardTitle>
                    <CardDescription>
                      Manage your account information and preferences.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center gap-6">
                      <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                        {user?.profileImageUrl ? (
                          <img 
                            src={user.profileImageUrl} 
                            alt="Profile" 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <User className="w-10 h-10 text-primary" />
                        )}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">
                          {user?.firstName} {user?.lastName}
                        </h3>
                        <p className="text-muted-foreground">{user?.email}</p>
                      </div>
                    </div>

                    <div className="grid gap-4">
                      <div className="flex items-center justify-between py-3 border-b border-border">
                        <span className="text-muted-foreground">Total Readings</span>
                        <span className="font-semibold">{readings.length}</span>
                      </div>
                      <div className="flex items-center justify-between py-3 border-b border-border">
                        <span className="text-muted-foreground">Member Since</span>
                        <span className="font-semibold">
                          {user?.createdAt 
                            ? new Date(user.createdAt).toLocaleDateString()
                            : "N/A"}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-3">
                        <span className="text-muted-foreground">Latest Health Score</span>
                        <span className="font-semibold">
                          {readings[0]?.healthScore || "N/A"}/100
                        </span>
                      </div>
                    </div>

                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => window.location.href = "/api/logout"}
                      data-testid="button-logout"
                    >
                      Sign Out
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

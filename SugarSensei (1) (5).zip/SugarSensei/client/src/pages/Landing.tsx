import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { AssessmentForm } from "@/components/AssessmentForm";
import { ResultsDashboard } from "@/components/ResultsDashboard";
import { RecommendationsSection } from "@/components/RecommendationsSection";
import { DietaryGuidelines } from "@/components/DietaryGuidelines";
import { CareCenters } from "@/components/CareCenters";
import { EducationalCarousel } from "@/components/EducationalCarousel";
import { Footer } from "@/components/Footer";
import type { AssessmentResult, DiabetesStage } from "@shared/schema";

function calculateAssessment(
  bloodSugarLevel: number,
  age: number,
  fastingOrRandom: "fasting" | "random"
): AssessmentResult {
  let stage: DiabetesStage;
  let riskLevel: "low" | "moderate" | "high" | "critical";
  let healthScore: number;
  let bloodSugarStatus: string;
  let description: string;

  if (fastingOrRandom === "fasting") {
    if (bloodSugarLevel < 100) {
      stage = "normal";
      riskLevel = "low";
      healthScore = 90 - Math.floor(age / 10);
      bloodSugarStatus = "Normal Range";
      description = "Your fasting blood sugar level is within the normal range. Keep maintaining your healthy lifestyle to stay on track!";
    } else if (bloodSugarLevel < 126) {
      stage = "prediabetes";
      riskLevel = "moderate";
      healthScore = 70 - Math.floor(age / 10);
      bloodSugarStatus = "Prediabetes Range";
      description = "Your blood sugar indicates prediabetes. This is a warning sign, but with lifestyle changes, you can prevent progression to diabetes.";
    } else {
      stage = "type2";
      riskLevel = bloodSugarLevel >= 200 ? "critical" : "high";
      healthScore = Math.max(30, 50 - Math.floor((bloodSugarLevel - 126) / 5) - Math.floor(age / 10));
      bloodSugarStatus = "Diabetes Range";
      description = "Your blood sugar level indicates diabetes. Please consult with a healthcare professional for proper diagnosis and treatment plan.";
    }
  } else {
    if (bloodSugarLevel < 140) {
      stage = "normal";
      riskLevel = "low";
      healthScore = 85 - Math.floor(age / 10);
      bloodSugarStatus = "Normal Range";
      description = "Your random blood sugar level is within the normal range. Continue with your healthy habits!";
    } else if (bloodSugarLevel < 200) {
      stage = "prediabetes";
      riskLevel = "moderate";
      healthScore = 65 - Math.floor(age / 10);
      bloodSugarStatus = "Elevated Range";
      description = "Your blood sugar is elevated. Consider getting a fasting blood sugar test for a more accurate assessment.";
    } else {
      stage = "type2";
      riskLevel = bloodSugarLevel >= 300 ? "critical" : "high";
      healthScore = Math.max(25, 45 - Math.floor((bloodSugarLevel - 200) / 10) - Math.floor(age / 10));
      bloodSugarStatus = "High Range";
      description = "Your random blood sugar is significantly elevated. It's important to see a healthcare provider as soon as possible.";
    }
  }

  healthScore = Math.max(10, Math.min(100, healthScore));

  const recommendations = stage === "normal" 
    ? [
        "Continue regular exercise routine",
        "Maintain balanced diet with whole grains",
        "Schedule annual health checkups",
        "Stay hydrated throughout the day",
      ]
    : stage === "prediabetes"
    ? [
        "Increase physical activity to 150 min/week",
        "Reduce refined carbohydrate intake",
        "Consider meeting with a nutritionist",
        "Monitor blood sugar regularly",
        "Achieve and maintain healthy weight",
      ]
    : [
        "Consult an endocrinologist immediately",
        "Start blood sugar monitoring routine",
        "Follow prescribed medication regimen",
        "Make immediate dietary changes",
        "Consider diabetes education program",
      ];

  const nextSteps = stage === "normal"
    ? ["Annual HbA1c test", "Maintain healthy lifestyle", "Regular exercise"]
    : stage === "prediabetes"
    ? ["Get HbA1c test", "Schedule nutrition consultation", "Start exercise program"]
    : ["Urgent medical consultation", "Complete diabetes panel", "Start treatment plan"];

  return {
    stage,
    riskLevel,
    healthScore,
    bloodSugarStatus,
    description,
    recommendations,
    nextSteps,
  };
}

export default function Landing() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null);
  const [currentBloodSugar, setCurrentBloodSugar] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const assessmentRef = useRef<HTMLDivElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleGetStarted = () => {
    assessmentRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleNavigate = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleAssessmentSubmit = async (data: {
    bloodSugarLevel: number;
    age: number;
    fastingOrRandom: "fasting" | "random";
    weight?: number;
    height?: number;
  }) => {
    setIsSubmitting(true);
    
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    const result = calculateAssessment(
      data.bloodSugarLevel,
      data.age,
      data.fastingOrRandom
    );
    
    setAssessmentResult(result);
    setCurrentBloodSugar(data.bloodSugarLevel);
    setIsSubmitting(false);
    
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        user={user} 
        isLoading={isLoading} 
        onNavigate={handleNavigate}
      />
      
      <main className="pt-16">
        <HeroSection 
          isAuthenticated={isAuthenticated}
          onGetStarted={handleGetStarted}
        />

        <div ref={assessmentRef}>
          <AssessmentForm 
            onSubmit={handleAssessmentSubmit}
            isSubmitting={isSubmitting}
          />
        </div>

        {assessmentResult && (
          <motion.div
            ref={resultsRef}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <ResultsDashboard 
              result={assessmentResult}
              bloodSugarLevel={currentBloodSugar}
            />
          </motion.div>
        )}

        <RecommendationsSection />
        <DietaryGuidelines />
        <CareCenters />
        <EducationalCarousel />
        <Footer />
      </main>
    </div>
  );
}
